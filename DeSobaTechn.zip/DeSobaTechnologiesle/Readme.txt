How to run the DeSoba Technologies (DST) Project

1. Download the  zip file

2. Extract the file and copy bms folder

3.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with name bmsdb

6. Import bmsdb.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/bms (frontend)



Credential for admin panel :

Username: admin
Password: Test@123

Credential for  Sub-admin panel:

Username: subadmin
Password: Test@123

 Or Register a new subadmin.